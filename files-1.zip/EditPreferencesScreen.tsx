import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';
import { Colors, BorderRadius } from '../theme';

interface EditPreferencesScreenProps {
  navigation: any;
}

const INTERESTS = ['Photography', 'Coffee', 'Travel', 'Music', 'Books', 'Animals'];

export default function EditPreferencesScreen({ navigation }: EditPreferencesScreenProps) {
  const [lookingFor, setLookingFor] = useState<'Women' | 'Men' | 'Everyone'>('Everyone');
  const [ageMin, setAgeMin] = useState(21);
  const [ageMax, setAgeMax] = useState(30);
  const [location] = useState('Delhi, India');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'Photography', 'Coffee', 'Travel', 'Music', 'Books', 'Animals',
  ]);
  const [distance, setDistance] = useState(70); // percentage along slider
  const [saving, setSaving] = useState(false);

  const toggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const handleSave = () => {
    setSaving(true);
    // TODO: POST /api/user/preferences with { lookingFor, ageMin, ageMax, location, selectedInterests, distance }
    setTimeout(() => {
      setSaving(false);
      Alert.alert('Saved!', 'Your preferences have been updated.', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    }, 1000);
  };

  const handleAddMore = () => {
    // TODO: Navigate to interests picker screen
    Alert.alert('Add Interests', 'Interest picker coming soon!');
  };

  // Slider value display: 10km to 100km range, distance is 0-100 percent
  const distanceValue = Math.round(10 + (distance / 100) * 90);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit Preferences</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
        {/* Looking For */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>I'm looking for</Text>
          <View style={styles.toggleGroup}>
            {(['Women', 'Men', 'Everyone'] as const).map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.toggleBtn,
                  lookingFor === option && styles.toggleBtnActive,
                ]}
                onPress={() => setLookingFor(option)}
              >
                <Text
                  style={[
                    styles.toggleBtnText,
                    lookingFor === option && styles.toggleBtnTextActive,
                  ]}
                >
                  {option}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Age Range */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Age Range</Text>
          <View style={styles.sliderContainer}>
            <Text style={styles.sliderMin}>21</Text>
            <View style={styles.sliderTrack}>
              <View style={styles.sliderFill} />
              <View style={[styles.sliderThumb, { left: '20%' }]} />
              <View style={[styles.sliderThumb, { left: '55%' }]} />
            </View>
            <Text style={styles.sliderMax}>30</Text>
          </View>
        </View>

        {/* Location */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Location</Text>
          <View style={styles.locationRow}>
            <Text style={styles.locationValue}>{location}</Text>
            <TouchableOpacity onPress={() => Alert.alert('Edit Location', 'Location picker coming soon!')}>
              <Text style={styles.editIcon}>✏</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Interests */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Interests</Text>
          <View style={styles.chipsWrap}>
            {INTERESTS.map((interest) => (
              <TouchableOpacity
                key={interest}
                style={[
                  styles.interestChip,
                  selectedInterests.includes(interest) && styles.interestChipActive,
                ]}
                onPress={() => toggleInterest(interest)}
              >
                <Text
                  style={[
                    styles.interestChipText,
                    selectedInterests.includes(interest) && styles.interestChipTextActive,
                  ]}
                >
                  {interest}
                </Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.addMoreChip} onPress={handleAddMore}>
              <Text style={styles.addMoreText}>+ Add more</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Distance */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Distance</Text>
          <View style={styles.sliderContainer}>
            <Text style={styles.sliderMin}>10 km</Text>
            <View style={styles.sliderTrack}>
              <View style={[styles.sliderFillDistance, { width: '70%' }]} />
              <View style={[styles.sliderThumb, { left: '70%' }]} />
            </View>
            <Text style={styles.sliderMax}>100 km</Text>
          </View>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Save Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.saveBtn, saving && styles.saveBtnLoading]}
          onPress={handleSave}
          activeOpacity={0.8}
          disabled={saving}
        >
          <Text style={styles.saveBtnText}>
            {saving ? 'Saving...' : 'Save Preferences'}
          </Text>
        </TouchableOpacity>
        <View style={styles.homeIndicator} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  backBtn: {
    padding: 4,
    width: 40,
  },
  backArrow: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '300',
  },
  headerTitle: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '700',
  },
  scroll: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 28,
  },
  sectionLabel: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 14,
  },
  toggleGroup: {
    flexDirection: 'row',
    gap: 10,
  },
  toggleBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: BorderRadius.lg,
    backgroundColor: Colors.bgCard,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  toggleBtnActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  toggleBtnText: {
    color: Colors.primaryLight,
    fontSize: 14,
    fontWeight: '500',
  },
  toggleBtnTextActive: {
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  sliderMin: {
    color: Colors.textPrimary,
    fontSize: 14,
    minWidth: 24,
  },
  sliderMax: {
    color: Colors.textPrimary,
    fontSize: 14,
    minWidth: 28,
    textAlign: 'right',
  },
  sliderTrack: {
    flex: 1,
    height: 4,
    backgroundColor: Colors.border,
    borderRadius: 2,
    position: 'relative',
  },
  sliderFill: {
    position: 'absolute',
    left: '20%',
    right: '45%',
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 2,
  },
  sliderFillDistance: {
    position: 'absolute',
    left: 0,
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 2,
  },
  sliderThumb: {
    position: 'absolute',
    top: -8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.primary,
    transform: [{ translateX: -10 }],
  },
  locationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  locationValue: {
    color: Colors.textSecondary,
    fontSize: 15,
  },
  editIcon: {
    color: Colors.textSecondary,
    fontSize: 18,
  },
  chipsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  interestChip: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.bgChip,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  interestChipActive: {
    backgroundColor: Colors.bgChipSelected,
    borderColor: Colors.primary,
  },
  interestChipText: {
    color: Colors.primaryLight,
    fontSize: 14,
  },
  interestChipTextActive: {
    color: Colors.textPrimary,
  },
  addMoreChip: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: BorderRadius.full,
    borderWidth: 1.5,
    borderColor: Colors.primaryMuted,
    borderStyle: 'dashed',
  },
  addMoreText: {
    color: Colors.primaryLight,
    fontSize: 14,
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: Colors.bg,
  },
  saveBtn: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.md,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveBtnLoading: {
    opacity: 0.7,
  },
  saveBtnText: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: Colors.textPrimary,
    borderRadius: 3,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
    opacity: 0.3,
  },
});
