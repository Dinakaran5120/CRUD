import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';
import { Colors, BorderRadius } from '../theme';

interface SettingsScreenProps {
  navigation: any;
}

export default function SettingsScreen({ navigation }: SettingsScreenProps) {
  const [activeTab] = useState('ProfileTab');
  const [chatBadge] = useState(3);

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log Out',
        style: 'destructive',
        onPress: () => {
          // TODO: Clear auth tokens and navigate to Onboarding
          navigation.reset({ index: 0, routes: [{ name: 'Onboarding' }] });
        },
      },
    ]);
  };

  const handleNavItem = (item: string) => {
    switch (item) {
      case 'Edit Profile':
        // TODO: navigation.navigate('EditProfile');
        Alert.alert('Edit Profile', 'Edit profile screen coming soon!');
        break;
      case 'Preferences':
        navigation.navigate('EditPreferences');
        break;
      case 'Privacy':
        Alert.alert('Privacy', 'Privacy settings coming soon!');
        break;
      case 'Notifications':
        Alert.alert('Notifications', 'Notification settings coming soon!');
        break;
      case 'Safety & Security':
        Alert.alert('Safety & Security', 'Safety settings coming soon!');
        break;
      case 'Help Center':
        Alert.alert('Help Center', 'Opening Help Center...');
        break;
      case 'Contact Us':
        Alert.alert('Contact Us', 'Email: support@luptup.com');
        break;
      case 'Report a Problem':
        Alert.alert('Report a Problem', 'Problem reporting coming soon!');
        break;
      case 'Invite Friends':
        Alert.alert('Invite Friends', 'Share LupTup with your friends!');
        break;
      case 'Rate Lup Tup':
        Alert.alert('Rate Lup Tup', 'Taking you to the App Store...');
        break;
      case 'About Lup Tup':
        Alert.alert('About Lup Tup', 'Version 1.0.3\n© 2024 Lup Tup');
        break;
    }
  };

  const NavItem = ({ label, icon }: { label: string; icon: string }) => (
    <TouchableOpacity
      style={styles.navItem}
      onPress={() => handleNavItem(label)}
      activeOpacity={0.6}
    >
      <View style={styles.navItemLeft}>
        <Text style={styles.navIcon}>{icon}</Text>
        <Text style={styles.navLabel}>{label}</Text>
      </View>
      <Text style={styles.navChevron}>›</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* App Info */}
        <View style={styles.appInfoRow}>
          <View style={styles.appIconWrapper}>
            <View style={styles.appIcon}>
              <Text style={styles.appIconText}>LupTup</Text>
            </View>
          </View>
          <View style={styles.appInfoText}>
            <View style={styles.appNameRow}>
              <Text style={styles.appName}>Lup Tup</Text>
              <View style={styles.verifiedBadge}>
                <Text style={styles.verifiedIcon}>✓</Text>
              </View>
            </View>
            <Text style={styles.appTagline}>Meaningful connections start here</Text>
          </View>
        </View>

        {/* Account Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>Account</Text>
          <View style={styles.sectionCard}>
            <NavItem label="Edit Profile" icon="👤" />
            <View style={styles.divider} />
            <NavItem label="Preferences" icon="⊟" />
            <View style={styles.divider} />
            <NavItem label="Privacy" icon="🔒" />
            <View style={styles.divider} />
            <NavItem label="Notifications" icon="🔔" />
            <View style={styles.divider} />
            <NavItem label="Safety & Security" icon="🛡" />
          </View>
        </View>

        {/* Support Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>Support</Text>
          <View style={styles.sectionCard}>
            <NavItem label="Help Center" icon="❓" />
            <View style={styles.divider} />
            <NavItem label="Contact Us" icon="🎧" />
            <View style={styles.divider} />
            <NavItem label="Report a Problem" icon="⚑" />
          </View>
        </View>

        {/* More Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>More</Text>
          <View style={styles.sectionCard}>
            <NavItem label="Invite Friends" icon="👥" />
            <View style={styles.divider} />
            <NavItem label="Rate Lup Tup" icon="☆" />
            <View style={styles.divider} />
            <NavItem label="About Lup Tup" icon="ℹ" />
          </View>
        </View>

        {/* Log Out */}
        <View style={[styles.section, { marginBottom: 12 }]}>
          <TouchableOpacity style={styles.logoutCard} onPress={handleLogout}>
            <Text style={styles.logoutIcon}>→</Text>
            <Text style={styles.logoutText}>Log Out</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.version}>Version 1.0.3</Text>
        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Bottom Tab Bar */}
      <View style={styles.tabBar}>
        {[
          { key: 'Discover', label: 'Discover', icon: '⌂' },
          { key: 'Mood', label: 'Mood', icon: '✦' },
          { key: 'Matches', label: 'Matches', icon: '♡' },
          { key: 'Chats', label: 'Chats', icon: '💬', badge: chatBadge },
          { key: 'ProfileTab', label: 'Profile', icon: '👤' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={styles.tabItem}
            onPress={() => {
              if (tab.key !== 'ProfileTab' && tab.key !== 'Chats') {
                navigation.navigate('Main');
              }
            }}
          >
            <View style={styles.tabIconWrapper}>
              <Text
                style={[
                  styles.tabIcon,
                  activeTab === tab.key && styles.tabIconActive,
                ]}
              >
                {tab.icon}
              </Text>
              {tab.badge ? (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{tab.badge}</Text>
                </View>
              ) : null}
            </View>
            <Text
              style={[
                styles.tabLabel,
                activeTab === tab.key && styles.tabLabelActive,
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 12,
  },
  backBtn: {
    width: 40,
    padding: 4,
  },
  backArrow: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '300',
  },
  headerTitle: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '700',
  },
  appInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 16,
  },
  appIconWrapper: {},
  appIcon: {
    width: 72,
    height: 72,
    borderRadius: 16,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  appIconText: {
    color: Colors.textPrimary,
    fontSize: 12,
    fontWeight: '700',
  },
  appInfoText: {
    flex: 1,
  },
  appNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  appName: {
    color: Colors.textPrimary,
    fontSize: 18,
    fontWeight: '700',
  },
  verifiedBadge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedIcon: {
    color: Colors.textPrimary,
    fontSize: 12,
    fontWeight: '700',
  },
  appTagline: {
    color: Colors.textSecondary,
    fontSize: 13,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionHeader: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
  },
  sectionCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  navItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  navIcon: {
    fontSize: 20,
    color: Colors.primaryLight,
    width: 28,
    textAlign: 'center',
  },
  navLabel: {
    color: Colors.textPrimary,
    fontSize: 15,
  },
  navChevron: {
    color: Colors.textMuted,
    fontSize: 22,
    fontWeight: '300',
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginLeft: 58,
  },
  logoutCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  logoutIcon: {
    color: Colors.primaryLight,
    fontSize: 20,
    width: 28,
    textAlign: 'center',
  },
  logoutText: {
    color: Colors.primaryLight,
    fontSize: 15,
    fontWeight: '500',
  },
  version: {
    color: Colors.textMuted,
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 8,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    paddingBottom: 24,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  tabIconWrapper: {
    position: 'relative',
  },
  tabIcon: {
    fontSize: 22,
    color: Colors.tabInactive,
  },
  tabIconActive: {
    color: Colors.tabActive,
  },
  tabLabel: {
    fontSize: 10,
    color: Colors.tabInactive,
  },
  tabLabelActive: {
    color: Colors.tabActive,
    fontWeight: '600',
  },
  badge: {
    position: 'absolute',
    top: -6,
    right: -10,
    backgroundColor: Colors.badge,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: Colors.textPrimary,
    fontSize: 11,
    fontWeight: '700',
  },
});
