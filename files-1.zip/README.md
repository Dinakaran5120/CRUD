# Lup Tup Dating App — React Native

Pixel-perfect React Native implementation of all 6 screens from the Lup Tup dating app designs.

## Screens Implemented

| Screen | File | Source Image |
|--------|------|-------------|
| Onboarding | `OnboardingScreen.tsx` | Image 5 |
| Profile | `ProfileScreen.tsx` | Image 2 |
| Premium | `PremiumScreen.tsx` | Image 1 |
| Edit Preferences | `EditPreferencesScreen.tsx` | Image 3 |
| Advanced Filters | `AdvancedFiltersScreen.tsx` | Image 4 |
| Settings | `SettingsScreen.tsx` | Image 6 |
| Discover (bonus) | `DiscoverScreen.tsx` | Inferred from nav |

## Setup & Run

```bash
# Install dependencies
npm install

# Start Expo dev server
npx expo start

# Run on iOS
npx expo run:ios

# Run on Android
npx expo run:android
```

## Project Structure

```
LupTup/
├── App.tsx                      # Entry point
├── src/
│   ├── screens/
│   │   ├── OnboardingScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── PremiumScreen.tsx
│   │   ├── EditPreferencesScreen.tsx
│   │   ├── AdvancedFiltersScreen.tsx
│   │   ├── SettingsScreen.tsx
│   │   └── DiscoverScreen.tsx
│   ├── navigation/
│   │   └── AppNavigator.tsx
│   ├── theme/
│   │   └── index.ts             # All colors, spacing, fonts
│   └── types/
│       └── navigation.ts        # TypeScript navigation types
├── package.json
└── tsconfig.json
```

## Design Tokens (from screenshots)

```
Primary: #7B35E8
Primary Light: #9B6BFF
Background: #0D0D1A
Card BG: #14142A
Text Primary: #FFFFFF
Text Secondary: #A0A0C0
Border: #2A2A45
Online: #4CAF50
Badge: #FF3B30
```

## Interactive Behavior

### All buttons are functional:
- **Onboarding**: Swipeable slides, Skip/Next → Main app
- **Premium**: Plan selection state, Continue → mock payment flow + Alert
- **Profile**: Edit photo button, Settings nav, tab bar navigation
- **Edit Preferences**: Toggle buttons, mock sliders, interest chip toggles, Save → Alert
- **Advanced Filters**: All dropdowns (Alert pickers), lifestyle toggles, Reset → confirmation, Apply → goBack
- **Settings**: All nav items → appropriate handlers, Logout → confirmation + reset to Onboarding
- **Discover**: Like/Dislike/Super Like actions, crown → Premium, filter → AdvancedFilters

## TODO (Backend Integration)
- Replace all mock handlers with API calls
- `POST /api/likes` — like a profile
- `POST /api/passes` — pass on a profile  
- `GET /api/matches` — get matches list
- `POST /api/user/preferences` — save preferences
- `POST /api/user/filters` — save advanced filters
- `POST /api/premium/subscribe` — initiate subscription (Razorpay/IAP)
- Replace emoji placeholders with actual user images via `Image` component
- Implement real range sliders using `@react-native-community/slider`
- Add `react-native-linear-gradient` for button gradients
