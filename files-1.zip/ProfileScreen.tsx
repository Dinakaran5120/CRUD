import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Dimensions,
} from 'react-native';
import { Colors, Spacing, BorderRadius } from '../theme';

const { width } = Dimensions.get('window');

interface ProfileScreenProps {
  navigation: any;
}

const interestChips = ['Travel', 'Coffee', 'Music', 'Photography', 'Dogs'];
const fullInterests = ['Travel', 'Photography', 'Music', 'Books', 'Dogs', 'Coffee'];

export default function ProfileScreen({ navigation }: ProfileScreenProps) {
  const [activeTab, setActiveTab] = useState('ProfileTab');

  const handleSettings = () => {
    navigation.navigate('Settings');
  };

  const handleEditProfile = () => {
    // TODO: Navigate to edit profile screen
    console.log('Edit profile');
  };

  const handleTabPress = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'Discover') navigation.navigate('Discover');
    // TODO: handle other tabs
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleSettings} style={styles.settingsBtn}>
          <Text style={styles.settingsIcon}>⚙</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
        {/* Profile Photo */}
        <View style={styles.photoContainer}>
          <View style={styles.photoCircle}>
            <View style={styles.photoPlaceholder}>
              <Text style={styles.photoEmoji}>👩</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.editPhotoBtn} onPress={handleEditProfile}>
            <Text style={styles.editPhotoIcon}>✏</Text>
          </TouchableOpacity>
        </View>

        {/* Name & Info */}
        <View style={styles.nameRow}>
          <Text style={styles.name}>Anaya, 24</Text>
          <View style={styles.verifiedBadge}>
            <Text style={styles.verifiedIcon}>✓</Text>
          </View>
        </View>

        <Text style={styles.pronouns}>She/Her  |  Bisexual</Text>

        <View style={styles.locationRow}>
          <View style={styles.onlineDot} />
          <Text style={styles.locationText}>Online • Delhi, India • </Text>
          <Text style={styles.locationItalic}>3 km away</Text>
        </View>

        {/* Interest chips - top row */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.chipsScroll}
          contentContainerStyle={styles.chipsContainer}
        >
          {interestChips.map((chip) => (
            <View key={chip} style={styles.chip}>
              <Text style={styles.chipText}>{chip}</Text>
            </View>
          ))}
        </ScrollView>

        {/* About Me */}
        <View style={styles.aboutCard}>
          <Text style={styles.aboutTitle}>About me</Text>
          <Text style={styles.aboutText}>
            I love deep talks, spontaneous trips, and kind people. Let's create some memories ✨
          </Text>
        </View>

        {/* Interests Section */}
        <Text style={styles.sectionTitle}>Interests</Text>
        <View style={styles.interestsGrid}>
          {fullInterests.map((interest) => (
            <View key={interest} style={styles.interestChip}>
              <Text style={styles.interestChipText}>{interest}</Text>
            </View>
          ))}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Bottom Tab Bar */}
      <View style={styles.tabBar}>
        {[
          { key: 'Discover', label: 'Discover', icon: '⌂' },
          { key: 'Mood', label: 'Mood', icon: '✦' },
          { key: 'Matches', label: 'Matches', icon: '♡' },
          { key: 'Chats', label: 'Chats', icon: '💬', badge: 2 },
          { key: 'ProfileTab', label: 'Profile', icon: '👤' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={styles.tabItem}
            onPress={() => handleTabPress(tab.key)}
          >
            <View style={styles.tabIconWrapper}>
              <Text
                style={[
                  styles.tabIcon,
                  activeTab === tab.key && styles.tabIconActive,
                ]}
              >
                {tab.icon}
              </Text>
              {tab.badge && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{tab.badge}</Text>
                </View>
              )}
            </View>
            <Text
              style={[
                styles.tabLabel,
                activeTab === tab.key && styles.tabLabelActive,
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 12,
  },
  backBtn: {
    padding: 8,
  },
  backArrow: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '300',
  },
  settingsBtn: {
    padding: 8,
  },
  settingsIcon: {
    color: Colors.primaryLight,
    fontSize: 22,
  },
  scroll: {
    flex: 1,
  },
  photoContainer: {
    alignItems: 'center',
    marginTop: 8,
    position: 'relative',
  },
  photoCircle: {
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: Colors.bgCardDark,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoPlaceholder: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoEmoji: {
    fontSize: 80,
  },
  editPhotoBtn: {
    position: 'absolute',
    bottom: 0,
    right: width / 2 - 65 - 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  editPhotoIcon: {
    color: Colors.textPrimary,
    fontSize: 16,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    gap: 8,
  },
  name: {
    fontSize: 26,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  verifiedBadge: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedIcon: {
    color: Colors.textPrimary,
    fontSize: 14,
    fontWeight: '700',
  },
  pronouns: {
    color: Colors.textSecondary,
    fontSize: 15,
    textAlign: 'center',
    marginTop: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 6,
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.online,
    marginRight: 6,
  },
  locationText: {
    color: Colors.textSecondary,
    fontSize: 13,
  },
  locationItalic: {
    color: Colors.textSecondary,
    fontSize: 13,
    fontStyle: 'italic',
  },
  chipsScroll: {
    marginTop: 16,
  },
  chipsContainer: {
    paddingHorizontal: 20,
    gap: 8,
  },
  chip: {
    backgroundColor: Colors.bgChip,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipText: {
    color: Colors.primaryLight,
    fontSize: 13,
    fontWeight: '500',
  },
  aboutCard: {
    margin: 20,
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    padding: 16,
  },
  aboutTitle: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
  },
  aboutText: {
    color: Colors.textPrimary,
    fontSize: 15,
    lineHeight: 22,
  },
  sectionTitle: {
    color: Colors.textPrimary,
    fontSize: 18,
    fontWeight: '700',
    marginHorizontal: 20,
    marginBottom: 12,
  },
  interestsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 10,
  },
  interestChip: {
    backgroundColor: Colors.bgChip,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  interestChipText: {
    color: Colors.primaryLight,
    fontSize: 14,
    fontWeight: '500',
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    paddingBottom: 24,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  tabIconWrapper: {
    position: 'relative',
  },
  tabIcon: {
    fontSize: 22,
    color: Colors.tabInactive,
  },
  tabIconActive: {
    color: Colors.tabActive,
  },
  tabLabel: {
    fontSize: 10,
    color: Colors.tabInactive,
  },
  tabLabelActive: {
    color: Colors.tabActive,
    fontWeight: '600',
  },
  badge: {
    position: 'absolute',
    top: -6,
    right: -10,
    backgroundColor: Colors.badge,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: Colors.textPrimary,
    fontSize: 11,
    fontWeight: '700',
  },
});
