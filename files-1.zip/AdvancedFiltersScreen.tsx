import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';
import { Colors, BorderRadius } from '../theme';

interface AdvancedFiltersScreenProps {
  navigation: any;
}

const LIFESTYLE_OPTIONS = ['Non-smoker', 'Socially', 'Vegetarian', 'Sometimes drinks'];

export default function AdvancedFiltersScreen({ navigation }: AdvancedFiltersScreenProps) {
  const [lookingFor, setLookingFor] = useState<'Women' | 'Men' | 'Everyone'>('Everyone');
  const [relationshipGoal, setRelationshipGoal] = useState('Serious Relationship');
  const [ageMin] = useState(21);
  const [ageMax] = useState(35);
  const [heightMin] = useState(150);
  const [heightMax] = useState(190);
  const [education, setEducation] = useState("Bachelor's Degree");
  const [lifestyle, setLifestyle] = useState<string[]>([
    'Non-smoker', 'Socially', 'Vegetarian', 'Sometimes drinks',
  ]);
  const [kids, setKids] = useState('No');
  const [religion, setReligion] = useState('Spiritual');
  const [applying, setApplying] = useState(false);

  const toggleLifestyle = (option: string) => {
    if (lifestyle.includes(option)) {
      setLifestyle(lifestyle.filter((l) => l !== option));
    } else {
      setLifestyle([...lifestyle, option]);
    }
  };

  const handleReset = () => {
    Alert.alert('Reset Filters', 'Are you sure you want to reset all filters?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reset',
        style: 'destructive',
        onPress: () => {
          setLookingFor('Everyone');
          setRelationshipGoal('Serious Relationship');
          setEducation("Bachelor's Degree");
          setLifestyle([]);
          setKids('No');
          setReligion('Spiritual');
        },
      },
    ]);
  };

  const handleApply = () => {
    setApplying(true);
    // TODO: POST /api/user/filters with all filter state
    setTimeout(() => {
      setApplying(false);
      navigation.goBack();
    }, 800);
  };

  const showDropdown = (
    title: string,
    options: string[],
    current: string,
    onSelect: (v: string) => void
  ) => {
    Alert.alert(title, undefined, [
      ...options.map((o) => ({ text: o, onPress: () => onSelect(o) })),
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Advanced Filters</Text>
        <TouchableOpacity onPress={handleReset}>
          <Text style={styles.resetText}>Reset</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
        {/* Looking For */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>I'm looking for</Text>
          <View style={styles.toggleGroup}>
            {(['Women', 'Men', 'Everyone'] as const).map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.toggleBtn,
                  lookingFor === option && styles.toggleBtnActive,
                ]}
                onPress={() => setLookingFor(option)}
              >
                <Text
                  style={[
                    styles.toggleBtnText,
                    lookingFor === option && styles.toggleBtnTextActive,
                  ]}
                >
                  {option}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Relationship Goals */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Relationship Goals</Text>
          <TouchableOpacity
            style={styles.dropdown}
            onPress={() =>
              showDropdown(
                'Relationship Goals',
                ['Serious Relationship', 'Casual Dating', 'Friendship', 'Something New'],
                relationshipGoal,
                setRelationshipGoal
              )
            }
          >
            <Text style={styles.dropdownValue}>{relationshipGoal}</Text>
            <Text style={styles.dropdownArrow}>⌵</Text>
          </TouchableOpacity>
        </View>

        {/* Age Range */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Age Range</Text>
          <View style={styles.sliderContainer}>
            <Text style={styles.sliderLabel}>21</Text>
            <View style={styles.sliderTrack}>
              <View style={styles.sliderFill} />
              <View style={[styles.sliderThumb, { left: '18%' }]} />
              <View style={[styles.sliderThumb, { left: '52%' }]} />
            </View>
            <Text style={styles.sliderLabel}>35+</Text>
          </View>
        </View>

        {/* Height Range */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Height Range</Text>
          <View style={styles.sliderContainer}>
            <Text style={styles.sliderLabel}>150 cm</Text>
            <View style={styles.sliderTrack}>
              <View style={styles.sliderFillHeight} />
              <View style={[styles.sliderThumb, { left: '10%' }]} />
              <View style={[styles.sliderThumb, { left: '50%' }]} />
            </View>
            <Text style={styles.sliderLabel}>190 cm</Text>
          </View>
        </View>

        {/* Education */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Education</Text>
          <TouchableOpacity
            style={styles.dropdown}
            onPress={() =>
              showDropdown(
                'Education',
                ["Bachelor's Degree", "Master's Degree", 'PhD', 'High School', 'Other'],
                education,
                setEducation
              )
            }
          >
            <Text style={styles.dropdownValue}>{education}</Text>
            <Text style={styles.dropdownArrow}>⌵</Text>
          </TouchableOpacity>
        </View>

        {/* Lifestyle */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Lifestyle</Text>
          <View style={styles.chipsWrap}>
            {LIFESTYLE_OPTIONS.map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.lifestyleChip,
                  lifestyle.includes(option) && styles.lifestyleChipActive,
                ]}
                onPress={() => toggleLifestyle(option)}
              >
                <Text
                  style={[
                    styles.lifestyleChipText,
                    lifestyle.includes(option) && styles.lifestyleChipTextActive,
                  ]}
                >
                  {option}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* More Filters */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>More Filters</Text>
          <View style={styles.moreFiltersCard}>
            <View style={styles.moreFilterRow}>
              <Text style={styles.moreFilterLabel}>Kids</Text>
              <TouchableOpacity
                style={styles.moreFilterDropdown}
                onPress={() =>
                  showDropdown('Kids', ['No', 'Yes', 'Want someday', 'Open to it'], kids, setKids)
                }
              >
                <Text style={styles.moreFilterValue}>{kids}</Text>
                <Text style={styles.dropdownArrow}>⌵</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.moreFilterDivider} />
            <View style={styles.moreFilterRow}>
              <Text style={styles.moreFilterLabel}>Religion</Text>
              <TouchableOpacity
                style={styles.moreFilterDropdown}
                onPress={() =>
                  showDropdown(
                    'Religion',
                    ['Spiritual', 'Hindu', 'Muslim', 'Christian', 'Sikh', 'Buddhist', 'Agnostic', 'Atheist'],
                    religion,
                    setReligion
                  )
                }
              >
                <Text style={styles.moreFilterValue}>{religion}</Text>
                <Text style={styles.dropdownArrow}>⌵</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Apply Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.applyBtn, applying && styles.applyBtnLoading]}
          onPress={handleApply}
          activeOpacity={0.8}
          disabled={applying}
        >
          <Text style={styles.applyBtnText}>
            {applying ? 'Applying...' : 'Apply Filters'}
          </Text>
        </TouchableOpacity>
        <View style={styles.homeIndicator} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  backBtn: {
    width: 40,
    padding: 4,
  },
  backArrow: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '300',
  },
  headerTitle: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '700',
  },
  resetText: {
    color: Colors.primaryLight,
    fontSize: 15,
    fontWeight: '500',
  },
  scroll: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionLabel: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },
  toggleGroup: {
    flexDirection: 'row',
    gap: 10,
  },
  toggleBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: BorderRadius.lg,
    backgroundColor: Colors.bgCard,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  toggleBtnActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  toggleBtnText: {
    color: Colors.primaryLight,
    fontSize: 14,
    fontWeight: '500',
  },
  toggleBtnTextActive: {
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  dropdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  dropdownValue: {
    color: Colors.primaryLight,
    fontSize: 15,
  },
  dropdownArrow: {
    color: Colors.textSecondary,
    fontSize: 18,
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  sliderLabel: {
    color: Colors.textPrimary,
    fontSize: 13,
    minWidth: 32,
  },
  sliderTrack: {
    flex: 1,
    height: 4,
    backgroundColor: Colors.border,
    borderRadius: 2,
    position: 'relative',
  },
  sliderFill: {
    position: 'absolute',
    left: '18%',
    right: '48%',
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 2,
  },
  sliderFillHeight: {
    position: 'absolute',
    left: '10%',
    right: '50%',
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 2,
  },
  sliderThumb: {
    position: 'absolute',
    top: -8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.primary,
    transform: [{ translateX: -10 }],
  },
  chipsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  lifestyleChip: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.bgChip,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  lifestyleChipActive: {
    borderColor: Colors.primaryLight,
  },
  lifestyleChipText: {
    color: Colors.textSecondary,
    fontSize: 14,
  },
  lifestyleChipTextActive: {
    color: Colors.primaryLight,
  },
  moreFiltersCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  moreFilterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 14,
  },
  moreFilterDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginHorizontal: 14,
  },
  moreFilterLabel: {
    color: Colors.textPrimary,
    fontSize: 15,
  },
  moreFilterDropdown: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.bgInput,
    borderRadius: BorderRadius.md,
    paddingHorizontal: 14,
    paddingVertical: 8,
    minWidth: 120,
  },
  moreFilterValue: {
    color: Colors.textSecondary,
    fontSize: 14,
    flex: 1,
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: Colors.bg,
  },
  applyBtn: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.md,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
  },
  applyBtnLoading: {
    opacity: 0.7,
  },
  applyBtnText: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: Colors.textPrimary,
    borderRadius: 3,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
    opacity: 0.3,
  },
});
