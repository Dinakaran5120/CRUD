export const Colors = {
  // Backgrounds
  bg: '#0D0D1A',
  bgCard: '#14142A',
  bgCardDark: '#1A1A2E',
  bgInput: '#1C1C30',
  bgChip: '#1E1E35',
  bgChipSelected: '#4B2EB5',

  // Purple Brand
  primary: '#7B35E8',
  primaryGradientStart: '#9B4DFF',
  primaryGradientEnd: '#6B22D9',
  primaryLight: '#9B6BFF',
  primaryMuted: '#5A3A9A',

  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#A0A0C0',
  textMuted: '#6B6B8A',
  textPurple: '#9B6BFF',

  // Borders
  border: '#2A2A45',
  borderSelected: '#7B35E8',

  // Status
  online: '#4CAF50',
  error: '#FF4444',
  badge: '#FF3B30',

  // Tab bar
  tabInactive: '#6B6B8A',
  tabActive: '#9B6BFF',
};

export const Fonts = {
  regular: 'System',
  medium: 'System',
  semiBold: 'System',
  bold: 'System',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};
