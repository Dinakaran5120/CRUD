import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Alert,
  Dimensions,
} from 'react-native';
import { Colors, BorderRadius } from '../theme';

const { width, height } = Dimensions.get('window');

const MOCK_PROFILES = [
  { name: 'Priya', age: 22, location: 'Delhi, India', distance: '2 km', interests: ['Coffee', 'Books', 'Yoga'] },
  { name: 'Rhea', age: 25, location: 'Gurgaon, India', distance: '5 km', interests: ['Travel', 'Music', 'Art'] },
  { name: 'Ananya', age: 23, location: 'Delhi, India', distance: '1 km', interests: ['Dogs', 'Photography', 'Movies'] },
];

interface DiscoverScreenProps {
  navigation: any;
}

export default function DiscoverScreen({ navigation }: DiscoverScreenProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [liked, setLiked] = useState(false);
  const [activeTab, setActiveTab] = useState('Discover');

  const profile = MOCK_PROFILES[currentIdx % MOCK_PROFILES.length];

  const handleLike = () => {
    setLiked(true);
    // TODO: POST /api/likes { profileId }
    setTimeout(() => {
      setLiked(false);
      setCurrentIdx((i) => i + 1);
    }, 500);
  };

  const handleDislike = () => {
    // TODO: POST /api/passes { profileId }
    setCurrentIdx((i) => i + 1);
  };

  const handleSuperLike = () => {
    Alert.alert('Super Like!', 'Super like sent! ⭐');
    setCurrentIdx((i) => i + 1);
  };

  const handleTabPress = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'ProfileTab') navigation.navigate('Profile');
    if (tab === 'Settings') navigation.navigate('Settings');
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('Premium')}>
          <Text style={styles.crownIcon}>♛</Text>
        </TouchableOpacity>
        <View style={styles.logoWrap}>
          <Text style={styles.logoText}>LupTup</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('AdvancedFilters')}>
          <Text style={styles.filterIcon}>▽</Text>
        </TouchableOpacity>
      </View>

      {/* Card */}
      <View style={styles.cardContainer}>
        <View style={styles.card}>
          {/* Photo placeholder */}
          <View style={styles.cardPhoto}>
            <Text style={styles.cardPhotoEmoji}>
              {['👩', '👧', '🧑‍🦰'][currentIdx % 3]}
            </Text>
          </View>

          {/* Gradient overlay */}
          <View style={styles.cardGradient} />

          {/* Info */}
          <View style={styles.cardInfo}>
            <View style={styles.cardNameRow}>
              <Text style={styles.cardName}>{profile.name}, {profile.age}</Text>
              <View style={styles.verifiedBadge}>
                <Text style={styles.verifiedIcon}>✓</Text>
              </View>
            </View>
            <Text style={styles.cardLocation}>📍 {profile.location} • {profile.distance}</Text>
            <View style={styles.cardInterests}>
              {profile.interests.map((i) => (
                <View key={i} style={styles.cardChip}>
                  <Text style={styles.cardChipText}>{i}</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Like overlay indicator */}
          {liked && (
            <View style={styles.likeOverlay}>
              <Text style={styles.likeOverlayText}>LIKE ❤️</Text>
            </View>
          )}
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actions}>
        <TouchableOpacity style={[styles.actionBtn, styles.actionBtnDislike]} onPress={handleDislike}>
          <Text style={styles.actionBtnIcon}>✕</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.actionBtnSuperLike]} onPress={handleSuperLike}>
          <Text style={styles.actionBtnIcon}>⭐</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.actionBtnLike]} onPress={handleLike}>
          <Text style={styles.actionBtnIcon}>♥</Text>
        </TouchableOpacity>
      </View>

      {/* Bottom Tab Bar */}
      <View style={styles.tabBar}>
        {[
          { key: 'Discover', label: 'Discover', icon: '⌂' },
          { key: 'Mood', label: 'Mood', icon: '✦' },
          { key: 'Matches', label: 'Matches', icon: '♡' },
          { key: 'Chats', label: 'Chats', icon: '💬' },
          { key: 'ProfileTab', label: 'Profile', icon: '👤' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={styles.tabItem}
            onPress={() => handleTabPress(tab.key)}
          >
            <Text
              style={[
                styles.tabIcon,
                activeTab === tab.key && styles.tabIconActive,
              ]}
            >
              {tab.icon}
            </Text>
            <Text
              style={[
                styles.tabLabel,
                activeTab === tab.key && styles.tabLabelActive,
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 56,
    paddingBottom: 12,
  },
  crownIcon: {
    fontSize: 24,
    color: Colors.primaryLight,
  },
  logoWrap: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: BorderRadius.full,
  },
  logoText: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '700',
  },
  filterIcon: {
    fontSize: 24,
    color: Colors.primaryLight,
  },
  cardContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  card: {
    flex: 1,
    borderRadius: 20,
    backgroundColor: Colors.bgCard,
    overflow: 'hidden',
    position: 'relative',
  },
  cardPhoto: {
    flex: 1,
    backgroundColor: Colors.bgCardDark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardPhotoEmoji: {
    fontSize: 120,
  },
  cardGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 200,
    backgroundColor: 'rgba(13,13,26,0.85)',
  },
  cardInfo: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
  },
  cardNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  cardName: {
    color: Colors.textPrimary,
    fontSize: 24,
    fontWeight: '700',
  },
  verifiedBadge: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedIcon: {
    color: Colors.textPrimary,
    fontSize: 12,
    fontWeight: '700',
  },
  cardLocation: {
    color: Colors.textSecondary,
    fontSize: 13,
    marginBottom: 10,
  },
  cardInterests: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  cardChip: {
    backgroundColor: 'rgba(123,53,232,0.4)',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: Colors.primaryMuted,
  },
  cardChipText: {
    color: Colors.textPrimary,
    fontSize: 12,
  },
  likeOverlay: {
    position: 'absolute',
    top: 40,
    left: 20,
    backgroundColor: 'rgba(76,175,80,0.8)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 3,
    borderColor: '#4CAF50',
    transform: [{ rotate: '-15deg' }],
  },
  likeOverlayText: {
    color: Colors.textPrimary,
    fontSize: 22,
    fontWeight: '900',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
    gap: 20,
  },
  actionBtn: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  actionBtnDislike: {
    backgroundColor: '#2A1A1A',
    borderWidth: 1,
    borderColor: '#FF4444',
    shadowColor: '#FF4444',
  },
  actionBtnSuperLike: {
    backgroundColor: '#1A1A30',
    borderWidth: 1,
    borderColor: Colors.primaryLight,
    shadowColor: Colors.primary,
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  actionBtnLike: {
    backgroundColor: '#1A2A1A',
    borderWidth: 1,
    borderColor: '#4CAF50',
    shadowColor: '#4CAF50',
  },
  actionBtnIcon: {
    fontSize: 24,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.bgCard,
    paddingBottom: 24,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  tabIcon: {
    fontSize: 22,
    color: Colors.tabInactive,
  },
  tabIconActive: {
    color: Colors.tabActive,
  },
  tabLabel: {
    fontSize: 10,
    color: Colors.tabInactive,
  },
  tabLabelActive: {
    color: Colors.tabActive,
    fontWeight: '600',
  },
});
