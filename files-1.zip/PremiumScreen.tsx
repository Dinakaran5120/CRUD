import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';
import { Colors, Spacing, BorderRadius } from '../theme';

interface PremiumScreenProps {
  navigation: any;
}

const features = [
  {
    icon: '💬',
    title: 'See who likes you',
    description: 'Connect with people who\nalready like you.',
  },
  {
    icon: '♡',
    title: 'Unlimited Likes',
    description: 'Like as many people as you want.',
  },
  {
    icon: '📋',
    title: 'Read Receipts',
    description: 'See when your messages\nare read.',
  },
  {
    icon: '▽',
    title: 'Advanced Filters',
    description: 'Find better matches with\nadvanced preferences.',
  },
];

const plans = [
  { id: '1m', duration: '1 Month', price: '₹599.00', save: null },
  { id: '3m', duration: '3 Months', price: '₹1,299.00', save: 'Save 27%' },
  { id: '12m', duration: '12 Months', price: '₹3,999.00', save: 'Save 44%' },
];

export default function PremiumScreen({ navigation }: PremiumScreenProps) {
  const [selectedPlan, setSelectedPlan] = useState('3m');
  const [loading, setLoading] = useState(false);

  const handleContinue = () => {
    setLoading(true);
    // TODO: Integrate with payment gateway (Razorpay/Google Pay/Apple Pay)
    setTimeout(() => {
      setLoading(false);
      Alert.alert('Premium Activated!', 'Welcome to Lup Tup Premium!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    }, 1500);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <View style={styles.titleRow}>
          <Text style={styles.crownIcon}>♛</Text>
          <Text style={styles.title}>Lup Tup Premium</Text>
        </View>
        <Text style={styles.subtitle}>Unlock meaningful connections</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
        {/* Features Card */}
        <View style={styles.featuresCard}>
          {features.map((feature, index) => (
            <View key={index} style={[styles.featureRow, index > 0 && styles.featureRowBorder]}>
              <View style={styles.featureIconBox}>
                <Text style={styles.featureIconText}>{feature.icon}</Text>
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDesc}>{feature.description}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Plans */}
        <View style={styles.plansRow}>
          {plans.map((plan) => (
            <TouchableOpacity
              key={plan.id}
              style={[
                styles.planCard,
                selectedPlan === plan.id && styles.planCardSelected,
              ]}
              onPress={() => setSelectedPlan(plan.id)}
              activeOpacity={0.8}
            >
              <Text
                style={[
                  styles.planDuration,
                  selectedPlan === plan.id && styles.planTextSelected,
                ]}
              >
                {plan.duration}
              </Text>
              <Text
                style={[
                  styles.planPrice,
                  selectedPlan === plan.id && styles.planTextSelected,
                ]}
              >
                {plan.price}
              </Text>
              {plan.save && (
                <View style={styles.saveBadge}>
                  <Text style={styles.saveBadgeText}>{plan.save}</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* Continue Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.continueBtn, loading && styles.continueBtnLoading]}
          onPress={handleContinue}
          activeOpacity={0.8}
          disabled={loading}
        >
          <Text style={styles.continueBtnText}>
            {loading ? 'Processing...' : 'Continue'}
          </Text>
        </TouchableOpacity>
        <View style={styles.homeIndicator} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 16,
  },
  backBtn: {
    marginBottom: 12,
  },
  backArrow: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '300',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 4,
  },
  crownIcon: {
    color: Colors.primaryLight,
    fontSize: 24,
  },
  title: {
    color: Colors.primaryLight,
    fontSize: 22,
    fontWeight: '700',
    fontStyle: 'italic',
  },
  subtitle: {
    color: Colors.textSecondary,
    fontSize: 14,
    marginLeft: 34,
  },
  scroll: {
    flex: 1,
  },
  featuresCard: {
    marginHorizontal: 20,
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    padding: 4,
    marginTop: 8,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 20,
    gap: 16,
  },
  featureRowBorder: {
    borderTopWidth: 0,
  },
  featureIconBox: {
    width: 52,
    height: 52,
    borderRadius: 12,
    backgroundColor: Colors.bgInput,
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureIconText: {
    fontSize: 22,
    color: Colors.primaryLight,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: Colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  featureDesc: {
    color: Colors.textSecondary,
    fontSize: 13,
    lineHeight: 18,
  },
  plansRow: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: 24,
    gap: 10,
  },
  planCard: {
    flex: 1,
    backgroundColor: Colors.bgCard,
    borderRadius: BorderRadius.lg,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
    minHeight: 110,
    justifyContent: 'center',
    gap: 4,
  },
  planCardSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.bgCardDark,
  },
  planDuration: {
    color: Colors.textSecondary,
    fontSize: 13,
    fontWeight: '500',
  },
  planPrice: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '700',
  },
  planTextSelected: {
    color: Colors.textPrimary,
  },
  saveBadge: {
    backgroundColor: Colors.bgChipSelected,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 4,
  },
  saveBadgeText: {
    color: Colors.primaryLight,
    fontSize: 12,
    fontWeight: '600',
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: Colors.bg,
  },
  continueBtn: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.full,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    // Gradient simulation - in production use LinearGradient
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  continueBtnLoading: {
    opacity: 0.7,
  },
  continueBtnText: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '600',
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: Colors.textPrimary,
    borderRadius: 3,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
    opacity: 0.3,
  },
});
