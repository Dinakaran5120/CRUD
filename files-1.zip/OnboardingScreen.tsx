import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  StatusBar,
  Image,
} from 'react-native';
import { Colors, Spacing, BorderRadius } from '../theme';

const { width, height } = Dimensions.get('window');

const slides = [
  {
    id: 1,
    titleWhite: 'Find someone',
    titlePurple: 'who gets you',
    subtitle: 'Lup Tup is a safe space for\nmeaningful connections.',
    // Using gradient placeholder - in production, use actual image
    imageBg: '#1a0a2e',
  },
  {
    id: 2,
    titleWhite: 'Match with',
    titlePurple: 'real people',
    subtitle: 'Verified profiles for\ngenuine connections.',
    imageBg: '#0a1a2e',
  },
  {
    id: 3,
    titleWhite: 'Chat without',
    titlePurple: 'boundaries',
    subtitle: 'Express yourself freely\nin a safe environment.',
    imageBg: '#1a2e0a',
  },
  {
    id: 4,
    titleWhite: 'Your perfect',
    titlePurple: 'match awaits',
    subtitle: 'Start your journey to\nmeaningful relationships.',
    imageBg: '#2e1a0a',
  },
];

interface OnboardingScreenProps {
  navigation: any;
}

export default function OnboardingScreen({ navigation }: OnboardingScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      // TODO: Navigate to auth/signup screen
      navigation.replace('Main');
    }
  };

  const handleSkip = () => {
    // TODO: Navigate to auth/signup screen
    navigation.replace('Main');
  };

  const slide = slides[currentSlide];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.bg} />

      {/* Skip button */}
      <TouchableOpacity style={styles.skipBtn} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Title */}
      <View style={styles.titleContainer}>
        <Text style={styles.titleWhite}>{slide.titleWhite}</Text>
        <Text style={styles.titlePurple}>{slide.titlePurple}</Text>
        <Text style={styles.subtitle}>{slide.subtitle}</Text>
      </View>

      {/* Hero Image Area */}
      <View style={[styles.heroContainer, { backgroundColor: slide.imageBg }]}>
        {/* Gradient overlay simulation */}
        <View style={styles.heroOverlay} />
        <View style={styles.heroImagePlaceholder}>
          <Text style={styles.heroEmoji}>💑</Text>
        </View>
      </View>

      {/* Dots indicator */}
      <View style={styles.dotsContainer}>
        {slides.map((_, index) => (
          <View
            key={index}
            style={[
              styles.dot,
              index === currentSlide ? styles.dotActive : styles.dotInactive,
            ]}
          />
        ))}
      </View>

      {/* Next button */}
      <TouchableOpacity style={styles.nextBtn} onPress={handleNext} activeOpacity={0.8}>
        <Text style={styles.nextBtnText}>
          {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
        </Text>
      </TouchableOpacity>

      {/* Home indicator */}
      <View style={styles.homeIndicator} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  skipBtn: {
    position: 'absolute',
    top: 60,
    right: 24,
    zIndex: 10,
  },
  skipText: {
    color: Colors.primaryLight,
    fontSize: 16,
    fontWeight: '500',
  },
  titleContainer: {
    paddingTop: 100,
    paddingHorizontal: 32,
    alignItems: 'center',
    zIndex: 5,
  },
  titleWhite: {
    fontSize: 32,
    fontWeight: '700',
    color: Colors.textPrimary,
    textAlign: 'center',
    lineHeight: 40,
  },
  titlePurple: {
    fontSize: 32,
    fontWeight: '700',
    color: Colors.primaryLight,
    textAlign: 'center',
    lineHeight: 40,
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 15,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  heroContainer: {
    flex: 1,
    marginTop: 32,
    position: 'relative',
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(13,13,26,0.3)',
  },
  heroImagePlaceholder: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroEmoji: {
    fontSize: 120,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingVertical: 20,
    gap: 8,
  },
  dot: {
    height: 8,
    borderRadius: 4,
  },
  dotActive: {
    width: 24,
    backgroundColor: Colors.primary,
  },
  dotInactive: {
    width: 8,
    backgroundColor: Colors.textMuted,
  },
  nextBtn: {
    marginHorizontal: 24,
    marginBottom: 16,
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.full,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextBtnText: {
    color: Colors.textPrimary,
    fontSize: 17,
    fontWeight: '600',
  },
  homeIndicator: {
    width: 134,
    height: 5,
    backgroundColor: Colors.textPrimary,
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 8,
    opacity: 0.3,
  },
});
